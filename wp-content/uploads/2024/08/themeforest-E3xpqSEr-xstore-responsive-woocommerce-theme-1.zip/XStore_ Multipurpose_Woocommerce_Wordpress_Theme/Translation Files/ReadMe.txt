You can find translation files in our GlotPress project https://www.8theme.com/glotpress/projects/xstore/ . 
This allows you to add your translation. Just follow a few steps https://make.wordpress.org/polyglots/handbook/translating/glotpress-translate-wordpress-org/

The final translations could then be downloaded and copied into the plugins and themes https://xstore.helpscoutdocs.com/article/30-base-theme-translation

Regards
8theme ltd.