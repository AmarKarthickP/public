PSD files have an efficient capacity (more than 1000Mb) and it slow down the uploading process of the theme package. You can find theme on 8theme.com/downloads

Regards
8theme ltd.